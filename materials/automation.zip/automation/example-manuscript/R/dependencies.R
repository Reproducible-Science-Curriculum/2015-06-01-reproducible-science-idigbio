## load needed packages
library(dplyr)
library(ggplot2)
library(knitr)

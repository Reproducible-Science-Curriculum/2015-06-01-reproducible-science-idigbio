# Files for File Organization lesson

The files are split into parts corresponding to activities.

1. `forensic-science` - directory for the Forensic Science activity
